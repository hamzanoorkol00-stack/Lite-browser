# Lite Browser for Android

This is the Android source project for Lite Browser. It uses Android's built-in WebView and DuckDuckGo as its start/search page.

## Build an APK using only your phone (GitHub Actions)

You do not need Android Studio or a PC for this cloud build route.

1. Sign in to GitHub in your phone browser and create a **new public or private repository** named `LiteBrowser`.
2. Extract this ZIP on your phone.
3. In the repository, use **Add file → Upload files** and upload the *contents* of the extracted `LiteBrowserAndroid` folder (including the hidden `.github` folder and its workflow file). If your file manager hides dot-folders, enable showing hidden files.
4. Commit the files to the `main` branch.
5. Open the repository's **Actions** tab. Select **Build Lite Browser APK** and tap **Run workflow** if it has not started automatically.
6. Wait for the workflow to finish successfully.
7. Open the completed workflow run, scroll to **Artifacts**, and download `LiteBrowser-debug-apk`.
8. Extract that artifact ZIP. It contains `app-debug.apk`. Tap the APK to install it. Android may ask you to allow installation from that source; only allow it if you trust the project you uploaded and built.

## App features

- Actual Android WebView browsing (not an HTML iframe).
- DuckDuckGo start page and search.
- Address bar with search-or-URL handling.
- Back, forward, reload and home controls.
- Minimal native Android interface.

## Limitations and privacy

- WebView is supplied by Android System WebView / the device's compatible browser provider.
- Some websites may not work fully in WebView or may require Chrome-specific features.
- This is an unsigned debug APK intended for personal testing, not Play Store distribution.
- JavaScript and DOM storage are enabled for modern websites. No analytics or advertising SDK is included.
- Browsing requests go directly to the websites you visit; DuckDuckGo is used for searches.
