package com.example.litebrowser

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.*
import android.widget.*

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private lateinit var address: EditText
    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private val homeUrl = "https://duckduckgo.com/"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF10151D.toInt())
        }
        val header = TextView(this).apply {
            text = "◉  Lite Browser"
            textSize = 18f
            setTextColor(0xFFE8EDF5.toInt())
            setPadding(16, 15, 16, 15)
            setBackgroundColor(0xFF18212D.toInt())
        }
        root.addView(header)

        val addressRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(10, 9, 10, 8)
        }
        address = EditText(this).apply {
            hint = "Search or enter website"
            singleLine = true
            textSize = 14f
            setTextColor(0xFFFFFFFF.toInt())
            setHintTextColor(0xFF9AAABD.toInt())
            setPadding(12, 8, 12, 8)
            setBackgroundColor(0xFF202B39.toInt())
            imeOptions = EditorInfo.IME_ACTION_GO
        }
        addressRow.addView(address, LinearLayout.LayoutParams(0, 48, 1f))
        val go = makeButton("Go") { navigate(address.text.toString()) }
        addressRow.addView(go, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, 48
        ).apply { leftMargin = 8 })
        root.addView(addressRow)

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(8, 0, 8, 8)
        }
        controls.addView(makeButton("←") { if (webView.canGoBack()) webView.goBack() })
        controls.addView(makeButton("→") { if (webView.canGoForward()) webView.goForward() })
        controls.addView(makeButton("↻") { webView.reload() })
        controls.addView(makeButton("⌂") { webView.loadUrl(homeUrl) })
        root.addView(controls)

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = android.view.View.GONE
        }
        root.addView(progress, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 3
        ))

        webView = WebView(this).apply {
            setBackgroundColor(0xFFFFFFFF.toInt())
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView, request: WebResourceRequest
                ): Boolean {
                    val uri = request.url
                    val scheme = uri.scheme ?: return true
                    if (scheme == "http" || scheme == "https") return false
                    return try {
                        startActivity(Intent(Intent.ACTION_VIEW, uri))
                        true
                    } catch (_: Exception) { true }
                }
                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    super.onPageStarted(view, url, favicon)
                    if (url != null) address.setText(url)
                    status.text = "Loading…"
                }
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    if (url != null) address.setText(url)
                    status.text = "Ready"
                }
                override fun onReceivedError(
                    view: WebView?, request: WebResourceRequest?, error: WebResourceError?
                ) {
                    super.onReceivedError(view, request, error)
                    if (request?.isForMainFrame == true)
                        status.text = "Could not load page — check connection"
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView?, newProgress: Int) {
                    progress.progress = newProgress
                    progress.visibility =
                        if (newProgress in 1..99) android.view.View.VISIBLE
                        else android.view.View.GONE
                }
            }
        }
        root.addView(webView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        status = TextView(this).apply {
            text = "Ready"
            textSize = 11f
            setTextColor(0xFF9AAABD.toInt())
            setPadding(12, 8, 12, 8)
            setBackgroundColor(0xFF18212D.toInt())
        }
        root.addView(status)
        setContentView(root)

        address.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO ||
                actionId == EditorInfo.IME_ACTION_DONE) {
                navigate(address.text.toString())
                true
            } else false
        }
        webView.loadUrl(homeUrl)
    }

    private fun makeButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 14f
            isAllCaps = false
            setTextColor(0xFFE8EDF5.toInt())
            setBackgroundTintList(
                android.content.res.ColorStateList.valueOf(0xFF202B39.toInt())
            )
            setPadding(8, 0, 8, 0)
            setOnClickListener { action() }
        }

    private fun navigate(input: String) {
        val text = input.trim()
        if (text.isEmpty()) return
        val url = when {
            text.startsWith("https://", true) || text.startsWith("http://", true) -> text
            text.matches(Regex("""[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)+([/:?#].*)?""")) ->
                "https://$text"
            else -> "https://duckduckgo.com/?q=" + Uri.encode(text)
        }
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(address.windowToken, 0)
        webView.loadUrl(url)
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }

    override fun onDestroy() {
        if (::webView.isInitialized) {
            webView.stopLoading()
            webView.destroy()
        }
        super.onDestroy()
    }
}
